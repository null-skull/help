# Helpperr — static (vanilla) site

Plain HTML, CSS and JavaScript copy of the Helpperr website. No build step or
framework needed.

- Open `index.html` in a browser, or upload this whole folder to any static
  host (Netlify, GitHub Pages, S3, a plain web server…).
- Pages: `index.html` (home), `pricing.html`, `contact.html`,
  `privacy-policy.html`, `login.html`.
- `assets/css/styles.css` is the site's stylesheet; `assets/js/main.js` runs
  all interactions (menu, FAQ, pricing seats, modals, forms, login flow,
  animations) using GSAP and Lenis, included locally in `assets/js`.

Forms and the login flow are front-end only (no backend), exactly like the
main site: they show their confirmation states but don't send anything.

This folder is generated — don't edit it by hand. In the main project run
`npm run export:vanilla` to regenerate it after changing the site.
